
import './style.css';
import { supabase } from './lib/supabase.js';

const fallbackProducts = [
  {name:'Oyun Paneli Pro',category:'Oyun',price:1250,badge:'Popüler',cls:'',tag:'Oyun Panelleri',features:'Özel Tasarım · Kolay Kurulum · Sınırsız Slot'},
  {name:'E-Ticaret Yönetim Paneli',category:'E-Ticaret',price:989,badge:'Yeni',cls:'green',tag:'E-Ticaret Panelleri',features:'Stok Yönetimi · Sipariş Takibi · Raporlama'},
  {name:'Hosting Paneli',category:'Hosting',price:1750,badge:'En Çok Satan',cls:'orange',tag:'Hosting Panelleri',features:'Sunucu Yönetimi · Otomatik Kurulum · 7/24 Destek'},
  {name:'Sosyal Medya Paneli',category:'Sosyal',price:1150,badge:'Popüler',cls:'',tag:'Sosyal Medya Panelleri',features:'Çoklu Hesap · Planlama · Analiz'},
  {name:'Kurumsal Web Sitesi',category:'Kurumsal',price:750,badge:'Yeni',cls:'green',tag:'Kurumsal Siteler',features:'Modern Tasarım · SEO Uyumlu · Mobil Uyumlu'},
  {name:'Restoran Web Sitesi',category:'Restoran',price:680,badge:'Öne Çıkan',cls:'',tag:'Restoran & Cafe',features:'Menü Yönetimi · Rezervasyon · Mobil Uyumlu'},
  {name:'Portföy Web Sitesi',category:'Portföy',price:620,badge:'Yeni',cls:'green',tag:'Portföy Siteleri',features:'Özel Tasarım · Hızlı Yükleme · SEO Uyumlu'},
  {name:'SaaS Dashboard',category:'SaaS',price:1450,badge:'En Çok Satan',cls:'orange',tag:'SaaS & Dashboard',features:'Analitik Raporlar · Kullanıcı Yönetimi · Ölçeklenebilir'}
];

const app = document.querySelector('#app');
app.innerHTML = `
  <div class="container">
    <nav class="nav">
      <div class="logo"><span>◢</span> Panel<i>Market</i></div>
      <div class="navlinks">
        <a class="active" href="#">⌂ Anasayfa</a>
        <a href="#paneller">▦ Paneller⌄</a>
        <a href="#paneller">▦ Kategoriler⌄</a>
        <a href="#fiyatlar">◉ Fiyatlar</a>
        <a href="#">▥ Hakkımızda</a>
        <a href="support.html">♧ Destek</a>
      </div>
      <div class="nav-actions"><button class="iconbtn" id="searchButton">⌕</button><button class="account" id="accountButton">♙ Hesabım</button></div>
    </nav>

    <section class="hero">
      <div class="hero-content">
        <div class="pills">⚡ Hızlı Teslimat　•　🛡 Güvenli Alışveriş</div>
        <h1>Profesyonel <span>Web Panelleri</span></h1>
        <p>Hazır yönetim panelleri ve modern web site temaları ile projenizi bir üst seviyeye taşıyın.</p>
        <button class="btn" id="exploreButton">▦ Panelleri İncele</button>
        <button class="btn alt" id="themesButton">✿ Tema Paketleri</button>
      </div>
      <div class="hero-art">
        <div class="screen back"><div class="dots"><i></i><i></i><i></i></div><h3>Web Store</h3><div class="chart"><b style="height:35%"></b><b style="height:65%"></b><b style="height:45%"></b><b style="height:90%"></b><b style="height:70%"></b></div></div>
        <div class="screen main"><div class="dots"><i></i><i></i><i></i></div><h3>Dashboard Analytics</h3><div class="chart"><b style="height:30%"></b><b style="height:55%"></b><b style="height:45%"></b><b style="height:82%"></b><b style="height:65%"></b><b style="height:100%"></b><b style="height:76%"></b></div></div>
      </div>
    </section>

    <section class="layout" id="paneller">
      <aside class="sidebar">
        <div class="side-title">▦　Kategoriler</div>
        <div class="categories" id="categories">
          <div class="cat active" data-category="Tümü">◈ Tüm Paneller <span>0</span></div>
          <div class="cat" data-category="Oyun">◉ Oyun Panelleri <span>0</span></div>
          <div class="cat" data-category="E-Ticaret">◇ E-Ticaret Panelleri <span>0</span></div>
          <div class="cat" data-category="Hosting">▤ Hosting Panelleri <span>0</span></div>
          <div class="cat" data-category="Sosyal">♧ Sosyal Medya <span>0</span></div>
          <div class="cat" data-category="Kurumsal">▣ Kurumsal Siteler <span>0</span></div>
          <div class="cat" data-category="Restoran">▥ Restoran & Cafe <span>0</span></div>
          <div class="cat" data-category="Portföy">▧ Portföy Siteleri <span>0</span></div>
          <div class="cat" data-category="SaaS">▨ SaaS & Dashboard <span>0</span></div>
        </div>
        <div class="range" id="fiyatlar"><div class="side-title">▤　Fiyat Aralığı</div><input type="range" min="50" max="5000" value="5000" id="priceRange"><div class="range-values"><span>50 TL</span><span id="priceValue">5.000 TL</span></div></div>
      </aside>

      <main class="content">
        <div class="toolbar">
          <select id="sort"><option value="new">☷ En Yeniler</option><option value="low">Fiyat: Artan</option><option value="high">Fiyat: Azalan</option></select>
          <input class="search" id="search" placeholder="⌕ Panel veya tema ara...">
        </div>
        <div class="grid" id="cardGrid"></div>
      </main>
    </section>
  </div>
    <div class="auth-overlay" id="authOverlay" aria-hidden="true">
      <div class="auth-modal" role="dialog" aria-modal="true">
        <button class="auth-close" id="authClose" type="button">×</button>
        <div class="auth-brand"><span>◢</span> Panel<i>Market</i></div>
        <h2 id="authTitle">Hesabına giriş yap</h2>
        <p class="auth-subtitle" id="authSubtitle">PanelMarket hesabınla devam et.</p>
        <div class="auth-tabs">
          <button class="auth-tab active" data-auth-mode="login" type="button">Giriş Yap</button>
          <button class="auth-tab" data-auth-mode="signup" type="button">Kayıt Ol</button>
        </div>
        <form id="authForm" class="auth-form">
          <label class="auth-label">E-posta<input id="authEmail" type="email" required placeholder="ornek@mail.com"></label>
          <label class="auth-label">Şifre<input id="authPassword" type="password" minlength="6" required placeholder="En az 6 karakter"></label>
          <label class="auth-label" id="authNameWrap" hidden>Ad Soyad<input id="authName" type="text" placeholder="Adınız ve soyadınız"></label>
          <button class="btn auth-submit" id="authSubmit" type="submit">Giriş Yap</button>
          <p class="auth-message" id="authMessage"></p>
        </form>
        <button class="auth-logout" id="logoutButton" type="button" hidden>Çıkış Yap</button>
      </div>
    </div>

`;

let products = [...fallbackProducts];
let active = 'Tümü';

const money = (n) => `${Number(n || 0).toLocaleString('tr-TR')} TL`;
const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
  '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
}[char]));

function normalizeProduct(row) {
  return {
    id: row.id,
    name: row.name || row.title || 'İsimsiz Ürün',
    category: row.category || row.cat || 'Tümü',
    price: Number(row.price || 0),
    badge: row.badge || 'Yeni',
    cls: row.cls || '',
    tag: row.tag || row.category || 'Web Paneli',
    features: row.features || row.description || 'Modern Tasarım · Kolay Kurulum · Mobil Uyumlu',
    image_url: row.image_url || '',
    download_url: row.download_url || row.file_url || ''
  };
}

function updateCategoryCounts() {
  const categories = ['Tümü', 'Oyun', 'E-Ticaret', 'Hosting', 'Sosyal', 'Kurumsal', 'Restoran', 'Portföy', 'SaaS'];
  document.querySelectorAll('.cat').forEach((item) => {
    const category = item.dataset.category;
    const count = category === 'Tümü'
      ? products.length
      : products.filter((product) => String(product.category || '').trim().toLocaleLowerCase('tr-TR') === category.toLocaleLowerCase('tr-TR')).length;
    const counter = item.querySelector('span');
    if (counter) counter.textContent = String(count);
  });
}

function renderCards() {
  updateCategoryCounts();
  const query = document.querySelector('#search').value.toLowerCase().trim();
  const maxPrice = Number(document.querySelector('#priceRange').value);
  let list = products.filter((product) => {
    const searchable = `${product.name} ${product.category} ${product.tag} ${product.features}`.toLowerCase();
    return (active === 'Tümü' || product.category === active)
      && product.price <= maxPrice
      && searchable.includes(query);
  });

  const sort = document.querySelector('#sort').value;
  if (sort === 'low') list.sort((a, b) => a.price - b.price);
  if (sort === 'high') list.sort((a, b) => b.price - a.price);

  document.querySelector('#cardGrid').innerHTML = list.map((product) => {
    const preview = product.image_url
      ? `<img class="product-image" src="${escapeHtml(product.image_url)}" alt="${escapeHtml(product.name)}" loading="lazy">`
      : `<div class="mock-window"><div class="mock-top"></div><div class="mock-body"><div class="mock-side"></div><div class="mock-main"></div></div></div>`;

    return `
      <article class="card">
        <div class="preview">
          <span class="badge ${escapeHtml(product.cls)}">${escapeHtml(product.badge)}</span>
          ${preview}
        </div>
        <div class="card-body">
          <h3>${escapeHtml(product.name)}</h3>
          <span class="tag">${escapeHtml(product.tag)}</span>
          <div class="features">${escapeHtml(product.features)}</div>
          <div class="card-bottom">
            <div class="price">${money(product.price)}</div>
            <button class="details" data-product-id="${escapeHtml(product.id || '')}">Detayları Gör　→</button>
          </div>
        </div>
      </article>
    `;
  }).join('') || '<p>Bu filtrelere uygun ürün bulunamadı.</p>';

  document.querySelectorAll('.details').forEach((button) => {
    button.addEventListener('click', () => {
      const product = products.find((item) => String(item.id || '') === button.dataset.productId);
      if (!product) return;
      const params = new URLSearchParams({
        id: String(product.id || ''), name: product.name || '', category: product.category || '',
        tag: product.tag || '', price: String(product.price || 0), badge: product.badge || '',
        features: product.features || '', description: product.description || '', image_url: product.image_url || '', download_url: product.download_url || product.file_url || ''
      });
      window.location.href = `detail.html?${params.toString()}`;
    });
  });
}

function selectCategory(category, element) {
  active = category;
  document.querySelectorAll('.cat').forEach((item) => item.classList.remove('active'));
  element.classList.add('active');
  renderCards();
}

async function loadProductsFromSupabase() {
  if (!supabase) return;

  const { data, error } = await supabase
    .from('products')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Supabase ürünleri alınamadı:', error);
    return;
  }

  if (Array.isArray(data)) {
    products = data.map(normalizeProduct);
    renderCards();
  }
}

document.querySelectorAll('.cat').forEach((item) => {
  item.addEventListener('click', () => selectCategory(item.dataset.category, item));
});
document.querySelector('#search').addEventListener('input', renderCards);
document.querySelector('#sort').addEventListener('change', renderCards);
document.querySelector('#priceRange').addEventListener('input', (event) => {
  document.querySelector('#priceValue').textContent = money(event.target.value);
  renderCards();
});
document.querySelector('#exploreButton').addEventListener('click', () => {
  document.querySelector('#paneller').scrollIntoView({ behavior: 'smooth' });
});
document.querySelector('#themesButton').addEventListener('click', () => {
  alert('Tema paketleri yakında listelenecek.');
});
document.querySelector('#searchButton').addEventListener('click', () => {
  const searchInput = document.querySelector('#search');
  searchInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
  setTimeout(() => {
    searchInput.focus();
    searchInput.classList.add('search-focused');
    setTimeout(() => searchInput.classList.remove('search-focused'), 1200);
  }, 350);
});

document.querySelector('#search').addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    document.querySelector('#cardGrid').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
});


let authMode = 'login';
let currentUser = null;
const authOverlay = document.querySelector('#authOverlay');
const authForm = document.querySelector('#authForm');
const authTitle = document.querySelector('#authTitle');
const authSubtitle = document.querySelector('#authSubtitle');
const authSubmit = document.querySelector('#authSubmit');
const authMessage = document.querySelector('#authMessage');
const authNameWrap = document.querySelector('#authNameWrap');
const authName = document.querySelector('#authName');
const logoutButton = document.querySelector('#logoutButton');
const accountButton = document.querySelector('#accountButton');

function authMsg(text, error=false) {
  authMessage.textContent = text;
  authMessage.classList.toggle('error', error);
}
function setAuthMode(mode) {
  authMode = mode;
  document.querySelectorAll('.auth-tab').forEach(t => t.classList.toggle('active', t.dataset.authMode === mode));
  const signup = mode === 'signup';
  authTitle.textContent = signup ? 'Hesap oluştur' : 'Hesabına giriş yap';
  authSubtitle.textContent = signup ? 'PanelMarket hesabını hemen oluştur.' : 'PanelMarket hesabınla devam et.';
  authSubmit.textContent = signup ? 'Kayıt Ol' : 'Giriş Yap';
  authNameWrap.hidden = !signup;
  authName.required = signup;
  authMsg('');
}
function openAuth(mode='login') {
  authForm.hidden = false;
  logoutButton.hidden = true;
  setAuthMode(mode);
  authOverlay.classList.add('open');
  authOverlay.setAttribute('aria-hidden','false');
  document.querySelector('#authEmail').focus();
}
function closeAuth() {
  authOverlay.classList.remove('open');
  authOverlay.setAttribute('aria-hidden','true');
}
function updateAccount() {
  if (currentUser) accountButton.textContent = `♙ ${currentUser.email}`;
  else accountButton.textContent = '♙ Giriş Yap / Kayıt Ol';
}
async function syncSession() {
  if (!supabase) return;
  const { data } = await supabase.auth.getSession();
  currentUser = data?.session?.user || null;
  updateAccount();
}
document.querySelectorAll('.auth-tab').forEach(t => t.addEventListener('click', () => setAuthMode(t.dataset.authMode)));
document.querySelector('#authClose').addEventListener('click', closeAuth);
authOverlay.addEventListener('click', e => { if (e.target === authOverlay) closeAuth(); });
accountButton.addEventListener('click', () => {
  if (!currentUser) return openAuth('login');
  authForm.hidden = true;
  logoutButton.hidden = false;
  authTitle.textContent = 'Hesabın açık';
  authSubtitle.textContent = currentUser.email;
  authOverlay.classList.add('open');
  authOverlay.setAttribute('aria-hidden','false');
});
logoutButton.addEventListener('click', async () => {
  if (supabase) await supabase.auth.signOut();
  currentUser = null;
  updateAccount();
  closeAuth();
  authForm.hidden = false;
  logoutButton.hidden = true;
});
authForm.addEventListener('submit', async e => {
  e.preventDefault();
  authSubmit.disabled = true;
  authMsg('');
  const email = document.querySelector('#authEmail').value.trim();
  const password = document.querySelector('#authPassword').value;
  try {
    if (!supabase) throw new Error('Supabase istemcisi bulunamadı.');
    let result;
    if (authMode === 'signup') {
      result = await supabase.auth.signUp({
        email, password,
        options: { data: { full_name: authName.value.trim() } }
      });
      if (result.error) throw result.error;
      authMsg(result.data.session ? 'Kayıt başarılı!' : 'Kayıt başarılı. E-postanı doğrula.');
      if (result.data.user) { currentUser = result.data.user; updateAccount(); }
    } else {
      result = await supabase.auth.signInWithPassword({ email, password });
      if (result.error) throw result.error;
      currentUser = result.data.user;
      updateAccount();
      authMsg('Giriş başarılı!');
      setTimeout(closeAuth, 600);
    }
  } catch (err) {
    authMsg(err.message || 'İşlem başarısız.', true);
  } finally {
    authSubmit.disabled = false;
    authSubmit.textContent = authMode === 'signup' ? 'Kayıt Ol' : 'Giriş Yap';
  }
});
supabase?.auth.onAuthStateChange((_event, session) => {
  currentUser = session?.user || null;
  updateAccount();
});
syncSession();

renderCards();
loadProductsFromSupabase();

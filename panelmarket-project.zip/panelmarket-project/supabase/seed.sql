insert into public.products (name, category, price, description)
values
  ('Oyun Paneli Pro', 'Oyun', 1250, 'Modern oyun paneli teması'),
  ('E-Ticaret Yönetim Paneli', 'E-Ticaret', 989, 'Ürün ve sipariş yönetimi'),
  ('Hosting Paneli', 'Hosting', 1750, 'Sunucu yönetim paneli');

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  price numeric(10,2) not null default 0,
  description text,
  image_url text,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;

create policy "Products are publicly readable"
on public.products
for select
using (true);
